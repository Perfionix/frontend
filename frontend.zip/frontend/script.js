function contactUs() {
  window.location.href = "#contact";
}
// Dynamic base URL: local or production
const BASE_URL = window.location.hostname.includes("localhost")
  ? "http://localhost:4000"
  : "https://<your-backend-app>.railway.app"; // Replace with actual backend URL after deploy

// Example POST request to /api/contact
async function submitContactForm(data) {
  try {
    const response = await fetch(`${BASE_URL}/api/contact`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(data)
    });

    const result = await response.json();
    console.log("Server response:", result);
  } catch (error) {
    console.error("Error sending data to backend:", error);
  }
}

